<?php 
include('./connectDB.php');
$key = $_POST['suggest'];
$SelectAcount = sqlsrv_query($conn, "SELECT * FROM Account where Malop = '$key' ");
$count = 1; while($row = sqlsrv_fetch_array($SelectAcount)) {?>
                    <tr>
                        <td><?php echo $count; ?></td>
                        <td><?php echo $row['MSSV']; ?></td>
                        <td><?php echo $row['FName']; ?></td>
                        <td><?php $Date = $row['DOB']->format('d/m/Y'); echo $Date; ?></td>
                        <td><?php echo $row['Sex']; ?></td>
                        <td><?php echo $row['GPA']; ?></td>
                        <?php 
                            if(strcasecmp($row['Trangthai'],'Khen thưởng') == 0){
                        ?>      <td style="color:#0151e3;"><?php echo $row['Trangthai']; ?></td> 
                        <?php } else if(strcasecmp($row['Trangthai'],'Không') == 0){
                        ?>      <td style="color:#FFFFF;"><?php echo $row['Trangthai']; ?></td>
                        <?php 
                            }else if(strcasecmp($row['Trangthai'], 'Thiếu học phí') == 0){
                        ?>      <td style="color:darkgoldenrod;"><?php echo $row['Trangthai']; ?></td>
                        <?php }else if(strcasecmp($row['Trangthai'],'Cảnh cáo') == 0){ ?>
                                <td style="color:coral;"><?php echo $row['Trangthai']; ?></td>
                        <?php } else if(strcasecmp($row['Trangthai'],'Nghỉ học') == 0){ ?>
                                <td style="color:coral;"><?php echo $row['Trangthai']; ?></td>
                        <?php }?>
                        <td>
                            <a class="btn btn-warning" href="../editProfile.php?mssv=<?php echo $row['MSSV']; ?>"><i class='bx bx-info-circle'></i> Chi tiết</a>
                            <a class="btn btn-danger" href="#"><i class='bx bxs-trash-alt' ></i>Delete</i></a>
                        </td>
                    </tr>
<?php $count++; } ?>