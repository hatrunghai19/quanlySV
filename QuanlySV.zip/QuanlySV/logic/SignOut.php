<?php
	session_start();
	include './php/connection.php';
	unset($_SESSION['chucvu']);
	header("Location: ../login.php");
?>