<?php 
    include('./connectDB.php');
    if(isset($_POST['editProfile'])){
        $MSSV = $_GET['mssv'];
        $username = $_POST['name'];
        $DOB = date("Y-m-d", strtotime(str_replace('/', '-', $_POST['birthday'])));;
        $Sex = $_POST['gender'];
        $email = $_POST['mail'];
        $addr = $_POST['address'];
        
        $insert = "UPDATE [dbo].[Account]
        SET 
           [FName] = N'$username'
           ,[Mail] = '$email'
           ,[Sex] = N'$Sex'
           ,[DOB] = '$DOB'
           ,[Addr] = N'$addr'
      WHERE MSSV = $MSSV ";
            if(sqlsrv_query($conn, $insert)){
                header("Location: ../sinhvien.php");
            }else{
                echo "ERROR: Không thể thêm bản ghi $insert";
            }  
        }
?>