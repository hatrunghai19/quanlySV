<?php 
    include('./connectDB.php');
    if(isset($_POST['addAccount'])){
        $MSSV = $_POST['mssv'];
        $username = $_POST['Name'];
        $DOB = date("Y-m-d", strtotime(str_replace('/', '-', $_POST['DOB'])));;
        $Sex = $_POST['sex'];
        $email = $_POST['email'];
        $addr = $_POST['addr'];
        $tinchi = $_POST['tinchi'];
        $gpa = $_POST['gpa'];
        $trangthai = $_POST['trangthai'];
        $lop = $_POST['lop'];
        
        $insert = "INSERT INTO Account
        (MSSV
        ,pass
        ,FName
        ,Mail
        ,Sex
        ,DOB
        ,GPA
        ,Addr
        ,Malop
        ,Trangthai
        ,Sotin)
  VALUES
        ('$MSSV'
        ,'$MSSV'
        ,N'$username'
        ,'$email'
        ,N'$Sex'
        ,'$DOB'
        ,'$gpa'
        ,N'$addr'
        ,'$lop'
        ,'$trangthai'
        ,'$tinchi')";
            if(sqlsrv_query($conn, $insert)){
                header("Location: ../sinhvien.php");
            }else{
                echo "ERROR: Không thể thêm bản ghi $insert";
            }  
        }
?>