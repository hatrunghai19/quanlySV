$(document).ready(function(){
    $(".SelectClass").change(function(){
      var txt = $(".SelectClass").val();
      $.post("../logic/listSV.php", {suggest: txt}, function(result){
        $(".list").html(result);
      });
    });
  });