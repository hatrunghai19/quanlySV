<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Login Page in HTML with CSS Code Example</title>
  <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous"><link rel="stylesheet" href="./css/style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div class="box-form">
	<div class="left">
		<div class="overlay">
		<h1>Quản lý sinh viên</h1>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
		Curabitur et est sed felis aliquet sollicitudin</p>
		
		</div>
	</div>
	
	
	<div class="right">
		<form action="./logic/login.php" method="post">
			<h5 style="text-align: center;" >Đăng nhập</h5>
			<div class="inputs">
				<input type="text" name="user" placeholder="Tài khoản">
				<br>
				<input type="password" name="password" placeholder="Mật khẩu">
			</div>
				
				<br><br>
				
			<div class="remember-me--forget-password">
					<!-- Angular -->
				<label>
					<input type="checkbox" name="item" checked/>
					<span class="text-checkbox">Nhớ mật khẩu</span>
				</label>
			</div>
				<br>
				<button>Đăng nhập</button>
		</form>
	</div>
		
</div>
<!-- partial -->
  
</body>
</html>