$(document).ready(function(){
    $(".SelectClass").change(function(){
      var txt = $(".SelectClass").val();
      $.post("../logic/listSV.php", {suggest: txt}, function(result){
        $(".list").html(result);
      });
    });

    $(document).on('click', '.del_button', function(){
      var del = $(this).val();
      $.post("../logic/DeleteSinhVien.php", {mssv: del}, function(result){
        var classSV = $(".SelectClass").val();
        $.post("../logic/listSV.php", {suggest: classSV}, function(result){
        $(".list").html(result);
      });
      });
    });
});