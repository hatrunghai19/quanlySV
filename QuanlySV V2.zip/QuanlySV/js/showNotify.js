$(document).ready(function(){
    $(".SelectClass").change(function(){
      var txt = $(".SelectClass").val();
      $.post("../logic/showNotify.php", {suggest: txt}, function(result){
        $(".messages").html(result);
      });
    });
  });
