$(document).ready(function(){
    $("button").click(function(){
        var class = $(".SelectClass").val();
        var mess = $(".inputSend").val();
        $.post("../logic/addNotify.php", {class: class, mess: mess}, function(result){
            alert(result);
          });
        });
      });