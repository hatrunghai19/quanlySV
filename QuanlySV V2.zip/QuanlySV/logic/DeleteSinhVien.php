<?php
    include('./connectDB.php');
    $mssv = $_POST['mssv'];
    $DeleteSV = sqlsrv_query($conn, "DELETE FROM Account WHERE mssv = '$mssv' ");
    $DeleteUser = sqlsrv_query($conn, "DELETE FROM tblUser WHERE userName = '$mssv' ");
    
?>