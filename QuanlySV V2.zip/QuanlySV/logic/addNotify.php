<?php 
    include('./connectDB.php');
    session_start();
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $username = $_SESSION['mssv'];
        $DOB = date("d/m/y H:i:s");
        $lop = $_POST['class'];
        $Mess = $_POST['Mess'];
        $insertNotify = "INSERT INTO Notify
        (LName
        ,Mess
        ,Lop
        ,DT)
  VALUES
        (N'$username'
        ,N'$Mess'
        ,'$lop'
        ,'$DOB')";
        if(sqlsrv_query($conn, $insertNotify)){
            // header("Location: ../notifi.php");
        }
    
?>