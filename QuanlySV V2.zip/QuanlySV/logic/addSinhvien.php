<?php 
    include('./connectDB.php');
    session_start();
    // if(isset($_POST['addAccount'])){
        $MSSV = $_POST['mssv'];
        $username = $_POST['Name'];
        $DOB = date("Y-m-d", strtotime(str_replace('/', '-', $_POST['DOB'])));;
        $Sex = $_POST['sex'];
        $email = $_POST['email'];
        $addr = $_POST['addr'];
        $tinchi = $_POST['tinchi'];
        $gpa = $_POST['gpa'];
        $trangthai = $_POST['trangthai'];
        $lop = $_POST['lop'];
        $CheckSV = sqlsrv_query($conn, "SELECT MaLop FROM Account WHERE MSSV = '$MSSV'");
        if($row = sqlsrv_fetch_array($CheckSV)){
            echo  "MSSV bị trùng";
        }else{
            $insertAccount = "INSERT INTO Account
            (MSSV
            ,pass
            ,FName
            ,Mail
            ,Sex
            ,DOB
            ,GPA
            ,Addr
            ,Malop
            ,Trangthai
            ,Sotin)
            VALUES
                ('$MSSV'
                ,'$MSSV'
                ,N'$username'
                ,'$email'
                ,N'$Sex'
                ,'$DOB'
                ,'$gpa'
                ,N'$addr'
                ,'$lop'
                ,N'$trangthai'
                ,'$tinchi')";
            sqlsrv_query($conn, "INSERT INTO tblUser
                (userName
                ,pass
                ,chucvu)
            VALUES
                ('$MSSV'
                ,'$MSSV'
                ,0)");
            $Check = sqlsrv_query($conn, "SELECT MaLop FROM tblMaLop WHERE MaLop = '$lop'");
            if($row = sqlsrv_fetch_array($Check)){
                if(sqlsrv_query($conn, $insertAccount)){
                }
            }else{
                $insertClass = "INSERT INTO tblMaLop
                    (MaLop)
                VALUES
                    ('$lop')";
                if(sqlsrv_query($conn, $insertAccount)){
                    if(sqlsrv_query($conn, $insertClass)){
                        echo "Thêm thành công";
                    }
                }
            }
            
        }    
    // }
?>