<?php
	session_start();
	include './php/connection.php';
	session_destroy();
	header("Location: ../login.php");
?>