<?php 
include('./connectDB.php');
$key = $_POST['suggest'];
$SelectNotify = sqlsrv_query($conn, "SELECT * FROM Notify where Lop = '$key' ORDER BY ID DESC ");
while($row = sqlsrv_fetch_array($SelectNotify)) {?>

<div class="message-box">
    <img src="https://images.unsplash.com/photo-1533993192821-2cce3a8267d1?ixid=MXwxMjA3fDB8MHxzZWFyY2h8MTl8fHdvbWFuJTIwbW9kZXJufGVufDB8fDB8&ixlib=rb-1.2.1&auto=format&fit=crop&w=900&q=60" alt="profile image">
    <div class="message-content">
        <div class="message-header">
            <div class="name"><?php echo $row['LName']; ?></div>
            <div class="star-checkbox">
                <input type="checkbox" id="star-4">
                <label for="star-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-star">
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></svg>
                </label>
            </div>
        </div>
        <p class="message-line"><?php echo $row['Mess']; ?></p>
        <p class="message-line time"><?php echo $row['DT']; ?></p>
    </div>
</div>
<?php } ?>